//
//  TicApp.swift
//  Shared
//
//  Created by Naresh Kumar on 2021-07-28.
//

import SwiftUI

@main
struct TicApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
