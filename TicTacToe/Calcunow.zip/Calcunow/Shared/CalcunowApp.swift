//
//  CalcunowApp.swift
//  Shared
//
//  Created by Naresh Kumar on 2021-07-21.
//

import SwiftUI

@main
struct CalcunowApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
